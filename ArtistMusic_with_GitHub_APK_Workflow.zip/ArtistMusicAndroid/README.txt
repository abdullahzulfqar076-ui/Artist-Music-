ARTIST MUSIC — Android Studio project

WHAT THIS IS
A starter Android app project wrapping the Artist Music player in a native Android WebView.
It includes a dark premium-style interface, local audio file picker, search, favorites, and playback.

BUILD THE APK
1. Install Android Studio on a computer.
2. Open the ArtistMusicAndroid folder in Android Studio.
3. Let Gradle sync. If prompted, install Android SDK Platform 35 and a compatible JDK.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location (usually app/build/outputs/apk/debug/app-debug.apk).

IMPORTANT
- This package is source code, not a precompiled APK.
- Building requires Android Studio/Android SDK on a computer.
- Music files are selected from the device; no songs are bundled.
- Favorites and the library list are currently session-based and reset when app data is cleared/restarted.
- Before public release, add a proper app icon, privacy policy, persistent library storage, testing,
  and Play Store signing/release configuration.
- Application ID: com.artistmusic.app



BUILD APK ON GITHUB FROM A PHONE
1. Upload the contents of this ZIP to the root of a GitHub repository (keep the .github folder).
2. In the repository, open the Actions tab.
3. Select "Build Artist Music APK" and tap "Run workflow" if it has not started automatically.
4. Wait for the run to finish successfully.
5. Open that completed run, find Artifacts, and download "Artist-Music-debug-APK".
6. Extract the downloaded artifact ZIP; it contains app-debug.apk.
